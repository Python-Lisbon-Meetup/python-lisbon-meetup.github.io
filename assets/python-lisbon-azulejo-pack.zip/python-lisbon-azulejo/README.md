# Python Lisbon — azulejo logo pack

The Python snakes painted on a Portuguese azulejo tile, plus four companion tiles (tram 28, Belém Tower, Ponte 25 de Abril, sardine) that share the same repeating pattern. Open `index.html` for a visual overview.

## Folders

| Folder | What's inside |
|---|---|
| `svg/icon/` | The main logo tile (`icon`), and a simplified version for very small sizes (`icon-simple`). |
| `svg/logo-horizontal/`, `svg/logo-stacked/`, `svg/wordmark/` | Versions with text, in `light` (for light backgrounds), `dark` (for dark backgrounds) and `auto` (switches with the viewer's light/dark setting; best for websites). |
| `svg/tiles/` | All five tiles with square edges. Place them side by side and the corner and edge ornaments join into a continuous pattern. |
| `svg/tiles-rounded/` | The same tiles with rounded corners, for use on their own. |
| `svg/medallions/` | Round crops of each tile (ring + picture), for small icons, avatars and bullets. |
| `svg/one-colour/` | One-colour logo (black or cobalt) for stamps, embroidery, laser engraving and single-colour print. |
| `png/icon/` | Logo tile, 16 to 4096 px. Sizes 48 px and below use the simplified version. |
| `png/tiles/`, `png/tiles-rounded/`, `png/medallions/` | Each tile and medallion in several sizes. |
| `png/logo-horizontal/`, `png/logo-stacked/`, `png/wordmark/` | Versions with text, transparent background, light and dark, in several widths. |
| `png/pattern/` | Seamless background pattern (repeats without visible seams), plus a snakes-only version. |
| `png/one-colour/` | One-colour logo in black and cobalt. |
| `favicon/` | `favicon.ico`, PNG favicons, Apple touch icon, Android/PWA icons, maskable icon, `site.webmanifest` and a `head-snippet.html` to paste into your site. |
| `web/` | Lightweight WebP versions of the tiles, medallions and pattern, exactly as used on the website. |
| `social/` | Avatars (1080), link preview (1200×630), banner (1500×500) and cover (1600×900), light and dark. |
| `slides/` | Title slide, content slide with a tile border, a plain pattern background, and a video-call background (1920×1080). |
| `stickers/` | Each tile with a white die-cut margin, ready to send to a sticker printer. |

## Which file do I use?

- **Website header:** `svg/logo-horizontal/python-lisbon-logo-horizontal-auto.svg`
- **Profile picture (Meetup, Discord, LinkedIn, GitHub):** `social/python-lisbon-avatar-light-1080.png` (circle-safe) or `social/python-lisbon-avatar-tile-1080.png` (full tile, for square avatars)
- **Favicon:** everything in `favicon/` and the snippet in `favicon/head-snippet.html`
- **Event announcement image:** `social/python-lisbon-og-light-1200x630.png`
- **Slides:** `slides/`
- **Merch and print:** the SVGs; `svg/one-colour/` when only one ink colour is available

## Palette

| Name | Hex | Use |
|---|---|---|
| Glaze Cream | `#F5EFE2` | Tile background |
| Cobalt | `#1C4E94` | Main blue, MEETUP on light |
| Deep Blue | `#123566` | Painted outlines |
| Sky Blue | `#6C9CD6` | Second snake, petals |
| Pale Blue | `#C3D8F1` | Highlights, tram and tower walls |
| Tram Yellow | `#F7C21B` | Accents: eyes, rosette centres, tram |
| Ink | `#13294B` | "Python Lisbon" text on light backgrounds |
| Night | `#0B1830` | Dark background |

On dark backgrounds the text is Glaze Cream with MEETUP in Tram Yellow. The tile itself never changes colour: like a real tile, it keeps its cream glaze on any background.

## Typeface

Rubik: Bold for "Python Lisbon", SemiBold for "MEETUP". Free under the SIL Open Font License (Google Fonts). All logo text is converted to outlines, so the logo files need no fonts installed.

## Guidelines

- Leave clear space around the logo of at least one eighth of the tile's width.
- Use the full tile from 64 px upwards. Below that, use `icon-simple` (favicons do this automatically).
- Don't recolour the tile, stretch it or put it on a busy photo without a plain panel behind it.
- The tram, tower, bridge and sardine tiles are companions, not replacements for the logo. Use them for patterns, event graphics and section icons.

## About the SVGs

The painted edges make the master SVGs fairly detailed (roughly 200–300 KB per tile). That's fine for print and design tools. For websites, use the files in `web/`, which are 17–43 KB each.
